import os
import time
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from openai import OpenAI


SCOPES = [
    "https://www.googleapis.com/auth/gmail.modify",  # хватает для modify + labels.list
]

# Имена папок должны ТОЧНО совпадать с тем, как они называются в Gmail
CATEGORIES = ["спам", "ВУЗ", "личное", "мессенджеры", "значимое", "остальное"]

openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Заходим в гмейл
def get_gmail_service():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as token:
            token.write(creds.to_json())
    return build("gmail", "v1", credentials=creds)


def get_label_ids(service, names):
    labels = service.users().labels().list(userId="me").execute().get("labels", [])
    by_name = {l["name"]: l["id"] for l in labels}
    found, missing = {}, []
    for n in names:
        if n in by_name:
            found[n] = by_name[n]
        else:
            missing.append(n)
    return found, missing

def list_inbox_messages(service, max_results=50):
    result = service.users().messages().list(
        userId="me",
        labelIds=["INBOX", "UNREAD"],
        maxResults=max_results,
    ).execute()
    return result.get("messages", [])

def get_headers(service, msg_id):
    msg = service.users().messages().get(
        userId="me",
        id=msg_id,
        format="metadata",
        metadataHeaders=["Subject", "From"],
    ).execute()
    headers = msg.get("payload", {}).get("headers", [])
    subjects = next((h["value"] for h in headers if h["name"].lower() == "subject"), "")
    sender = next((h["value"] for h in headers if h["name"].lower() == "from"), "")
    return subjects, sender

# Промт
def classify_email(subject: str, sender: str) -> str:
    system_prompt = (
        "Ты — агент сортировки почты. У тебя есть тема письма и отправитель. "
        "Выбери категорию из списка (можно выбрать одну из первых трех + скомбинировать с папкой Значимое):\n"
        "- ВУЗ (все что идет от домена msu.ru + мои переслыки с math.msu)\n"
        "- личное (только этот список: DELETED)\n"
        "- мессенджеры (уведомления Авито о статусе товаров, сообщения в ВК (кроме день рождений, их сразу в спам), коды из Телеграмм, Whatsapp и ТД, instagram и другое)\n"
        "- значимое (сюда можно отправлять что то что уже попало в другие категории, но оно должно быть для меня существенно значимым. Примеры: личные сообщения от инспектора курса (не рассылка), личные письма от лекторов и семинаристов (не рассылка всей группе или потоку), важные уведомления с госуслуг, банковские счета на оплату, др\n"
        "- остальное (если это нельзя 100% считать спамом, отправь сюда, я посмотрю)\n\n"
        "- спам (реклама, фишинг, массовые рассылки)\n"
        "Верни название категорий строчными буквами в формате abc, def, geh."
    )
    user_prompt = f"Отправитель: {sender}\nТема: {subjects}"

    try:
        response = openai_client.chat.completions.create(
            model="gpt-5o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0,
            max_tokens=10,
        )
        raw = response.choices[0].message.content.strip().lower()
        for cat in CATEGORIES:
            if cat in raw:
                return cat
        return "остальное"
    except Exception as e:
        print(f"Ошибка классификации: {e}")
        return "остальное"

def apply_label(service, msg_id, label_id, remove_inbox=True):
    body = {"addLabelIds": [label_id]}
    if remove_inbox:
        body["removeLabelIds"] = ["INBOX"]
    service.users().messages().modify(userId="me", id=msg_id, body=body).execute()


def main():
    service = get_gmail_service()

    label_ids, missing = get_label_ids(service, CATEGORIES)
    if missing:
        print("Не найдены папки в Gmail:", ", ".join(missing))
        return

    print("Все папки найдены:", {k: v[:8] + "…" for k, v in label_ids.items()})

    messages = list_inbox_messages(service, max_results=50)
    print(f"Найдено писем: {len(messages)}")

    for msg in messages:
        msg_id = msg["id"]
        subject, sender = get_headers(service, msg_id)

        category = classify_email(subject, sender)
        apply_label(service, msg_id, label_ids[category], remove_inbox=True)

        print(f"[{category:12s}] {sender[:40]:40s} | {subject[:60]}")
        time.sleep(0.3)

if __name__ == "__main__":
    main()